ComicCraft project specification package.

The uploaded PDF is a project design document, not a complete source repository.
A full working application would require generating many source files.
This package contains a placeholder README based on the specification.